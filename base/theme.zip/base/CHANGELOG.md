

# [1.1.0](https://github.com/IMIO/imio_library_themes/compare/v1.0.0...v1.1.0) (2024-12-17)

# 1.0.0 (2024-12-16)


### Bug Fixes

* couvin url ([eb4c521](https://github.com/IMIO/imio_library_themes/commit/eb4c52139794a3c21d73f0334d8cfdd53e76d3a8))


### Features

* **ci/cd:** add gha to build and deploy theme ([11cc723](https://github.com/IMIO/imio_library_themes/commit/11cc7233946db83d1f38b51bf253000da99184dd))

## [0.1.2](https://github.com/IMIO/imio_smartweb_themes/compare/v0.1.0...v0.1.2) (2024-08-05)


### Bug Fixes

* ol sublist counter ([76f0bbc](https://github.com/IMIO/imio_smartweb_themes/commit/76f0bbc231a29058cf22515bf030e22d96509ff6))

# [0.1.0](https://github.com/IMIO/imio_smartweb_themes/compare/0.0.6...v0.1.0) (2024-08-02)


### Bug Fixes

* : remove debug div ([7cf60e2](https://github.com/IMIO/imio_smartweb_themes/commit/7cf60e2c22ef782d781dcd713f9ef126f453a7d9))
* card-body height and icon [quick] ([4b67ef5](https://github.com/IMIO/imio_smartweb_themes/commit/4b67ef58129780e9d52756fb6a323ca1a1b0ac32))
* change procedure btn icon no displauy [skip ci] ([3cd3ff6](https://github.com/IMIO/imio_smartweb_themes/commit/3cd3ff6ec45fb1b8ec4eed5a9e935df5adfdac76))
* **ci/cd:** ERR_PNPM_OUTDATED_LOCKFILE ([3ce1928](https://github.com/IMIO/imio_smartweb_themes/commit/3ce1928c34b590c9295e94e26f2800748b451985))
* **ci/cd:** ERR_PNPM_OUTDATED_LOCKFILE (2) ([3a47022](https://github.com/IMIO/imio_smartweb_themes/commit/3a4702213a762c4f310ec9f27e12a7efdd4cc74a))
* **ci/cd:** use hash of package.json ([8d61443](https://github.com/IMIO/imio_smartweb_themes/commit/8d61443da5f8bd17e61969a904037d8039cccd0e))
* **ci:** environment vars are not available there ([f1c7562](https://github.com/IMIO/imio_smartweb_themes/commit/f1c7562378a8c51b4edad0ff84d76d8563e4b2c2))
* **ci:** id for summary step ([5123585](https://github.com/IMIO/imio_smartweb_themes/commit/5123585984e63ac7ab798683e3fba21a90cfa0dd))
* pettier fix [quick] ([83c28b8](https://github.com/IMIO/imio_smartweb_themes/commit/83c28b8c3d2c41c10f01f2e0c0faaf4bbbfd92bf))
* pettier fix [skip ci] ([e9fd7e6](https://github.com/IMIO/imio_smartweb_themes/commit/e9fd7e6b514fc922075d01ed33fbf5ca7bb501bc))
* **typo:** cat instead of echo ([9494c73](https://github.com/IMIO/imio_smartweb_themes/commit/9494c731437f1a69fca963943f74fa1886ae9e11))
* **typo:** missing " ([622ca75](https://github.com/IMIO/imio_smartweb_themes/commit/622ca75b8a8dd72bf647babada0d0dd68e09dfbf))


### Features

* awans base theme ([9788148](https://github.com/IMIO/imio_smartweb_themes/commit/97881487e178dfc5baf650271f645e043a27a901))
* awans base theme ([7d9e292](https://github.com/IMIO/imio_smartweb_themes/commit/7d9e2926695480ac2f96efb914494bb01e1d9986))
* base theme for beauvechain [quick] ([a3ebe3c](https://github.com/IMIO/imio_smartweb_themes/commit/a3ebe3cd773af7f02fe55420689ef0fe2a352bec))
* base theme for beauvechain [quick] ([0c6dc83](https://github.com/IMIO/imio_smartweb_themes/commit/0c6dc83eef175448dc5affbe9835a73c48139763))
* base theme for florennes [quick] ([28bfe5d](https://github.com/IMIO/imio_smartweb_themes/commit/28bfe5d2ecfab6f39657db20df8a96f1a322513d))
* base theme for florennes [quick] ([c783b92](https://github.com/IMIO/imio_smartweb_themes/commit/c783b92f1c7f8924825babe130f817089f152c35))
* base theme for montsaintguibert [quick] ([c631f6a](https://github.com/IMIO/imio_smartweb_themes/commit/c631f6ad6150632f22615ff2184215e45109aca8))
* base theme for montsaintguibert [quick] ([89e0680](https://github.com/IMIO/imio_smartweb_themes/commit/89e06808e749f7888697b482ffbd905dde6e70f3))
* base theme for montsaintguibert [quick] ([e6c0bc5](https://github.com/IMIO/imio_smartweb_themes/commit/e6c0bc5b46758b57861ef445795cee9c76cf6ed5))
* base theme for morlanwelz [quick] ([5710c63](https://github.com/IMIO/imio_smartweb_themes/commit/5710c6311c277918175045549996893fb1d61b25))
* base theme for mouscron [quick] ([9759c39](https://github.com/IMIO/imio_smartweb_themes/commit/9759c39b120364b0678884351cb393a873426fd9))
* base theme for pecq ([437fd1a](https://github.com/IMIO/imio_smartweb_themes/commit/437fd1af73d69c48fb886ccee36afd9c3f76fb6c))
* base theme for perwez [quick] ([27aa1a8](https://github.com/IMIO/imio_smartweb_themes/commit/27aa1a8d6ced18aa2dd6247b1d33a18138807a70))
* base theme for perwez quaregnon trooz ([587a7ed](https://github.com/IMIO/imio_smartweb_themes/commit/587a7ed43bbd958c58e58e319d42ad93a75f26b7))
* base theme for tintigny ([12c86da](https://github.com/IMIO/imio_smartweb_themes/commit/12c86daff672c89fa90a21c6fe6f6b4214d94547))
* base theme for tintigny ([967f9c8](https://github.com/IMIO/imio_smartweb_themes/commit/967f9c856cddfa9dc88cf240ee9b638d6af6a8cf))
* base theme for trooz [quick] ([68b8ac0](https://github.com/IMIO/imio_smartweb_themes/commit/68b8ac00dcb5960f889b6d19e8202ef1a061222f))
* base theme for verlain [quick] ([211a161](https://github.com/IMIO/imio_smartweb_themes/commit/211a161e98da78a97ac048981db08257a2045362))
* beauvechain florennes base theme ([56ad619](https://github.com/IMIO/imio_smartweb_themes/commit/56ad619bc0cd491ad498a82a7ccbe02bafb4569c))
* **ci/cd:** also cache pnpm-lock.yaml ([67819ef](https://github.com/IMIO/imio_smartweb_themes/commit/67819efca01d97faf404df0a84a1003230384726))
* **ci/cd:** bump mattermost-notify and rundeck-notify ([d09144c](https://github.com/IMIO/imio_smartweb_themes/commit/d09144ca2e66b0c905d120ee0e8d8029225beb1b))
* **ci/cd:** cache node_modules to speedup workflow ([50e5cf1](https://github.com/IMIO/imio_smartweb_themes/commit/50e5cf19167d22aabf195489e1aa138712c39b1f))
* **ci/cd:** cannot skip this in a monorepo ([a5ea207](https://github.com/IMIO/imio_smartweb_themes/commit/a5ea207867b6ffd474e3c5edd0eea06aa5335516))
* **ci/cd:** exclude some path from changed-directories ([0226915](https://github.com/IMIO/imio_smartweb_themes/commit/0226915a6a500c07f0e3673b9434498063df970e))
* **ci/cd:** ignore template folder ([b94319c](https://github.com/IMIO/imio_smartweb_themes/commit/b94319cf05d138fd837913fa5bd621d70b3d8f1a))
* **ci/cd:** lint ([f0de4cf](https://github.com/IMIO/imio_smartweb_themes/commit/f0de4cf058af76ff393fd73b44b7134a9037c25d))
* **ci/cd:** only install devdependecies if cache has not been restored ([61141d6](https://github.com/IMIO/imio_smartweb_themes/commit/61141d65f0b4ae7fe87371797c102d2f6bb67bde))
* **ci:** add a way to skip review and quick deploy ([49d05be](https://github.com/IMIO/imio_smartweb_themes/commit/49d05be35a2af9693f000171c27e21d24af840ee))
* **ci:** cat upload urls in workflow log and upload artifact ([b701eb3](https://github.com/IMIO/imio_smartweb_themes/commit/b701eb38e87aebea373ccea3a2ea90f923711c46))
* **ci:** notify on mattermost when pending review ([17998a6](https://github.com/IMIO/imio_smartweb_themes/commit/17998a663d59f925c81e1a18f50a853c49f6f6f3))
* **ci:** pin mattermost-notify v3.6 ([9bd3bfa](https://github.com/IMIO/imio_smartweb_themes/commit/9bd3bfaf502513319277e34ab529756b37a8b9ea))
* doische base theme [quick] ([a7d8bcb](https://github.com/IMIO/imio_smartweb_themes/commit/a7d8bcb87b3abbb5f02f00f47a39a4c01f692104))
* doische base theme [quick] ([ea24d1c](https://github.com/IMIO/imio_smartweb_themes/commit/ea24d1c2c4f4cbe13736d454e2df3a2a7bd1e5ad))
* **gha:** add paths-ignore and disable workflow dispatch ([2165ceb](https://github.com/IMIO/imio_smartweb_themes/commit/2165cebabdef56c92a2c8ba954cd8c406ccaad6a))
* **gha:** build base theme ([c4bb25d](https://github.com/IMIO/imio_smartweb_themes/commit/c4bb25d95ea616dd1e593fd7375b723f7197f09d))
* **gha:** push in pecq to launch workflow ([dca9ca9](https://github.com/IMIO/imio_smartweb_themes/commit/dca9ca9dc2bbab318f98c5729ea05550b17272a4))
* **gha:** upload base theme ([2506d47](https://github.com/IMIO/imio_smartweb_themes/commit/2506d47ff58f7b9eb6955f86c63c51c5cce99c49))
* **gha:** upload modified theme [skip ci] ([46fe8e5](https://github.com/IMIO/imio_smartweb_themes/commit/46fe8e58ac6af345b0bbdce290077d1701c0d1b9))
* **lint:** ignore scss/load-partial-extension ([aaf45e8](https://github.com/IMIO/imio_smartweb_themes/commit/aaf45e8b19f36d9cd0231277b2fdce45dbced0cb))
* morlanwelz base theme ([e4ba8d6](https://github.com/IMIO/imio_smartweb_themes/commit/e4ba8d622b95e48f1fc2b13a43256358f7f54ed0))
* sambreville base theme ([908e6d7](https://github.com/IMIO/imio_smartweb_themes/commit/908e6d76a12a9407cd16143845adb47db98362e7))
* sambreville base theme ([ce98edc](https://github.com/IMIO/imio_smartweb_themes/commit/ce98edc0e1ce2ea306484804eb2aebaf2f46dfa5))
* set homepages batch 1 ([5712daf](https://github.com/IMIO/imio_smartweb_themes/commit/5712dafe0dd7b307e7003a7660ffeed2dfc6dd9e))
* set homepages batch 2 [skip ci] ([a8f6350](https://github.com/IMIO/imio_smartweb_themes/commit/a8f63507839433490931abf6ee518b132fbddc35))
* set homepages batch 3 [skip ci] ([daad22c](https://github.com/IMIO/imio_smartweb_themes/commit/daad22cdc5a971f643890c5798aabe144a529827))
* set pecq instance url ([8d5df95](https://github.com/IMIO/imio_smartweb_themes/commit/8d5df95726a6c2722b6b9c62cb98267a6ac07ea0))
* soignies base theme ([393ce0c](https://github.com/IMIO/imio_smartweb_themes/commit/393ce0c22aa8e16c82222a0d181cb212bc61506c))
* soignies base theme ([4f9f538](https://github.com/IMIO/imio_smartweb_themes/commit/4f9f538172594557dbc4458c8162262d01a55de0))
* verlaine base theme ([d68fad8](https://github.com/IMIO/imio_smartweb_themes/commit/d68fad8cb8ff4a24330425560aee7b62fabd7b33))
* viroinval base theme ([3601ce9](https://github.com/IMIO/imio_smartweb_themes/commit/3601ce9544096c6ded9779737d4167270be197f5))
* walhain base theme [quick] ([1872ee2](https://github.com/IMIO/imio_smartweb_themes/commit/1872ee278da47e6851b53486c8b71db3a1d76db6))



## 0.0.6 (2023-03-07)
